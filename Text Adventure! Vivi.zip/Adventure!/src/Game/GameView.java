package Game;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import GameState.GameStateManager;
import Input.KeyManager;

@SuppressWarnings("serial")
public class GameView extends JFrame {

	/*
	 * This is a text render originally made by Leonardo.
	 * Picked up by Vivian.
	*/
	
	private Thread mainThread;
	protected JTextArea display = new JTextArea();
	private boolean running = false;
	private GameStateManager gsm;
	public Printer print;
	public KeyManager key; 
	
	public GameView() throws HeadlessException {
		setSize(new Dimension(420, 360));
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Text Game Test");
//		setVisible(true);
		gsm = new GameStateManager(gsm);
		print = new Printer();
		key = new KeyManager();
		
		display.setFont(new Font("Courier New", Font.BOLD, 16));
		display.setBackground(Color.black);
		display.setForeground(Color.green);
		display.addKeyListener(key);
		add(display);
		display.requestFocus();
		
		running = true;
		mainThread = new Thread(() -> {
			while(running) {
				//TODO Implement false check
				render();
				update();
				display.setText(print.convertScreenToText());
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) { e.printStackTrace(); }
			}
		});
		mainThread.start();
	}
	
	public void update() {
		key.update();
		gsm.update();
		gsm.getInput(key);
	}
	
	public void render() {
		print.clear();
		gsm.render(print);
		//TODO Implement other methods
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			GameView main = new GameView();
			main.setVisible(true);
		});
	}
	
}
