package Game;

public class Printer {

	private final int SCRNWIDTH = 101, SCRNHEIGHT = 24;
	private char[][] screen = new char[SCRNWIDTH][SCRNHEIGHT];
	
	protected void clear() {
		for(int y = 0; y < SCRNHEIGHT; y++) {
			for(int x = 0; x < SCRNWIDTH; x++) {
				screen[x][y] = ' ';
			}
		}
	}
	
	protected String convertScreenToText() {
		StringBuilder sb = new StringBuilder();
		for (int y = 0; y < SCRNHEIGHT; y++) {
			for(int x = 0; x < SCRNWIDTH; x++) {
				sb.append(screen[x][y]);
			}
			sb.append("\n");
		}
		return sb.toString();
	}
	
	public void print(int x, int y, String c) {
		for (int col = 0; col < c.length(); col++) {
			screen[x + col][y] = c.charAt(col);
		}
	}
}
