package GameState;

import Game.Printer;
import Input.KeyManager;

public abstract class GameState {

	protected GameStateManager gsm;
	protected Printer p = new Printer();
	protected KeyManager key = new KeyManager();
	
	public GameState(GameStateManager gsm) {
		this.gsm = gsm;
	}
	
	public abstract void update();
	public abstract void render(Printer p);
	public abstract void getInput(KeyManager key);
}
