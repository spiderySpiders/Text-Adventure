package GameState;
import Game.Printer;
import Input.KeyManager;

public class GameStateManager {

	private GameState[] gameState;
	
	private static final int GAMESTATES = 4;
	public static final int TITLESCREEN = 0;
	public static final int WORLDSCREEN = 1;
//	public static final int STATUSSCREEN = 2; Unimplemented State
//	public static final int SHOPSCREEN = 3; Unimplemented State
	private int currentState;
	private Printer p;
	
	public GameStateManager(GameStateManager gsm) {
		super();
		gameState = new GameState[GAMESTATES];
		currentState = TITLESCREEN;
		loadState(currentState);
	}
	
	public void loadState(int state) {
		if(state == TITLESCREEN) {
			gameState[state] = new Title(this);
		} else if(state == WORLDSCREEN) {
			gameState[state] = new World(this);
//		} else if(state == STATUSSCREEN) {
//			gameState[state] = new Stat(this);
//		} else if(state == SHOPSCREEN) {
//			gameState[state] = new Shop(this);
		} else {
			gameState[state] = new Title(this);
		}
		
	}
	
	public void unloadState(int state) {
		gameState[state] = null;
	}
	
	public void setState(int state) {
		unloadState(state);
		currentState = state;
		loadState(state);
	}
	
	public void update(){
		if(gameState[currentState] != null) { gameState[currentState].update(); }
	}
	public void render(Printer p) {
		if(gameState[currentState] != null) { gameState[currentState].render(p); }
	}
	public void getInput(KeyManager key) {
		if(gameState[currentState] != null) { gameState[currentState].getInput(key); }
	}
}
