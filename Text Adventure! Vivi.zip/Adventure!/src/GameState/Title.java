package GameState;

import Game.Printer;
import Input.KeyManager;

public class Title extends GameState {

	private static final int START = 0;
	private static final int EXIT = 1;
	private int currentSelect;
	private int cursorPos = 9;
	
	public Title(GameStateManager gsm) {
		super(gsm);
		System.out.println("Title created");
		currentSelect = 0;
	}

	protected void drawTitleScreen(Printer p) {
		p.print(13, 2, "#=============#");
		p.print(13, 3, "| Adventure!  |");
		p.print(13, 4, "#=============#");
	}
	
	protected void cursor(Printer p) {
		p.print(13, cursorPos, "==>");
	}
	
	protected void drawTitleOptions(Printer p) {
		p.print(18, 9, "START");
		p.print(18, 11, "EXIT");
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(Printer p) {
		drawTitleScreen(p);
		drawTitleOptions(p);
		
		cursor(p);
		
	}

	//Grabs the input of KeyManager to do TitleScreen stuff
	@Override
	public void getInput(KeyManager key) {
		if(key.up && currentSelect >= START) { currentSelect--;  }
		if(key.down && currentSelect <= EXIT) { currentSelect++;  }
		if(key.enter && currentSelect == START) { gsm.setState(GameStateManager.WORLDSCREEN); }
		else if(key.enter && currentSelect == EXIT) { System.exit(0); }
		switch(currentSelect) {
		case 0: cursorPos = 9; break;
		case 1: cursorPos = 11; break;
		}
		
//		System.out.println("Working!");
	}
	
}
