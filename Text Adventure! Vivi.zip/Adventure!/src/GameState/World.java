package GameState;

import java.util.Random;

import Game.Printer;
import Input.KeyManager;

public class World extends GameState{

	private Random ran = new Random();
	private int playerX = 5, playerY = 5, cursorX, cursorY;
	private char player = 'P';
	private int hp = 10;
	private String textBox = "Nothing...";
	private boolean looking = false;
	private char look1 = '=', look2 = '>';
	
	private int npcOneDir;
	private int npcOneY = 3, npcOneX = 3;
	private char npcOne = 'U';
	private char blankSpace = '.', rock = '#';
	private int cameraY = 11, cameraX = 15;
//	public char[][] testMap = {
//			{'#', '#', '.', '.', '.', '.', '.', '.', '.', '#', '#', '#', '.', '.', '.', '.', '#', '.' },
//			{'#', '.', '.', '.', '.', '.', '#', '.', '.', '#', '#', '#', '.', '.', '.', '.', '.', '.' },
//			{'#', '#', '#', '.', '.', '.', '#', '#', '.', '#', '#', '.', '.', '.', '.', '.', '.', '.' },
//			{'#', '#', '.', '.', '.', '.', '#', '#', '.', '.', '#', '.', '.', '.', '.', '.', '.', '.' },
//			{'#', '.', '.', '#', '.', '.', '.', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' },
//			{'.', '.', '#', '#', '#', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.' },
//			{'.', '.', '.', '#', '.', '.', '.', '.', '.', '#', '.', '.', '.', '.', '.', '.', '.', '.' },
//			{'.', '.', '.', '#', '.', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.' },
//			{'#', '.', '.', '#', '.', '.', '.', '#', '.', '#', '.', '.', '.', '.', '.', '.', '#', '.' },
//			{'.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' },
//			{'.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' },
//			{'.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' },
//			{'.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' },
//			{'.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' }
//			};
	public char[][] mapOne = { 
			{'#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'},
			{'#', '#', '.', '#', '#', '#', '#', '#', '.', '.', '.', '#', '#', '#', '#', '#', '#', '#', '.', '#', '#', '#', '.', '.', '#', '#', '#', '.', '#', '#', '#', '#', '#', '#', '#', '#'},
			{'#', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '.', '.', '.', '.', '#', '.', '.', '#', '#', '.', '.', '#', '#', '.', '.', '#', '#', '#', '#'},
			{'#', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '.', '.', '#', '#'},
			{'#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#'},
			{'#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#'},
			{'#', '#', '.', '.', '.', '.', '.', '.', '_', '_', '_', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#'},			
			{'#', '#', '.', '.', '.', '.', '.', '/', ' ', ' ', ' ', '\\', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '#'},			
			{'#', '#', '.', '.', '.', '.', '.', '|', ' ', ' ', ' ', '|', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '#'},
			{'#', '#', '.', '.', '.', '.', '.', '|', '_', 'D', '_', '|', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '#'},
			{'#', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '.', '#'},
			{'#', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '.', '.', '.', '.', '.', '.', '#'},
			{'#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '#', '#', '.', '.', '.', '.', '.', '_', '_', '_', '#', '#', '#', '.', '.', '.', '.', '#'},
			{'#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '#', '#', '#', '.', '.', '.', '/', ' ', ' ', ' ', '\\', '#', '#', '#', '#', '.', '#', '#'},			
			{'#', '#', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '#', '#', '#', '.', '.', '.', '|', ' ', ' ', ' ', '|', '#', '#', '#', '#', '#', '#', '#'},			
			{'#', '#', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '|', '_', '0', '_', '|', '#', '#', '.', '#', '#', '#', '#'},
			{'#', '#', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '.', '.', '.', '#', '#'},
			{'#', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#'},
			{'#', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#'},
			{'#', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#'},
			{'#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '#'},
			{'#', '#', '.', '.', '.', '.', '.', '.', '.', '#', '.', '.', '.', '.', '.', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '#'},
			{'#', '#', '.', '.', '.', '.', '.', '#', '#', '#', '#', '.', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '#'},
			{'#', '#', '#', '.', '.', '#', '#', '#', '#', '#', '#', '.', '#', '.', '#', '#', '.', '.', '.', '.', '#', '.', '.', '.', '.', '#', '#', '#', '#', '.', '.', '.', '.', '#', '.', '#'},
			{'#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '.', '.', '#', '.', '#', '#', '.', '#', '#', '#', '#', '#', '#', '#', '.', '.', '#', '#', '#', '#'},
			{'#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'},
	};
	public char[][] houseOne = { 
			{'#', '-', '-', '-', '-', '-', '-', '-', '-', '-', '#'},
			{'|', '.', '.', '.', '.', '.', '.', '.', '.', '.', '|'},
			{'|', '.', '.', '.', '.', '.', '.', '.', '.', 'h', '|'},
			{'|', '.', '.', '.', '.', '.', '.', '.', '.', 'T', '|'},
			{'|', '.', '.', '.', '.', '.', '.', '.', '.', 'h', '|'},
			{'|', '.', '.', '.', '.', '.', '.', '.', '.', '.', '|'},
			{'|', '.', '.', '.', '.', '.', '.', '.', '.', '.', '|'},
			{'#', '-', '-', '-', '-', 'D', '-', '-', '-', '-', '#'}
	};
	public char[][] currMap;

	// D = 10 x 10
	// 50 x 50
	// {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' }
	
	public World(GameStateManager gsm) {
		super(gsm);
		currMap = mapOne;
		// TODO Auto-generated constructor stub
	}
	
	public void playerUpdate() {
		currMap[playerY][playerX] = player;		
	}
	
	public void renderMapBorder(Printer p) {
		p.print(1, 1, "#===============#");
		p.print(1, 13, "#===============#");
		for(int i = 0; i < 11; i++) {
			p.print(1, 2 + i, "|               |");
		}
	}
	
	public void renderGuiBorder(Printer p) {
		p.print(20, 1, "#=============#");
		p.print(20, 8, "#=================#");
		p.print(20, 7, "#=============#");
		p.print(20, 15, "#=================#");
		for(int i = 0; i < 5; i++) {
			p.print(20, 2 + i, "|             |");
		}
		for(int i = 0; i < 6; i++) {
			p.print(20, 9 + i, "|                 |");
		}
	}
	
	public void renderGui(Printer p) {
		p.print(21, 2, "Look = K");
//		p.print(21, 3, "Stats = S"); Unimplemented method
//		p.print(21, 4, "Interact = I"); Unimplemented method
		p.print(21, 6, "Exit = Enter");
		textBox(p);
	}
	
	public void textBox(Printer p) {
		p.print(21, 9, textBox);
	}
	
	public void doorCheck() {
		try {
			if(currMap == mapOne) {
				if(currMap[9][9] == 'P') { playerX = 5; playerY = 6; currMap = houseOne; currMap[7][5] = 'D'; renderMap(p); }
			} 
			if(currMap == houseOne) {
				if(currMap[7][5] == 'P') { playerX = 9; playerY = 10; currMap = mapOne; currMap[9][9] = 'D'; renderMap(p); }
			}
			
		} catch(ArrayIndexOutOfBoundsException ex) { System.out.println("This gave an error!"); }
//		System.out.println(currMap[7][5]);
	}
	
	public void renderMap(Printer p) {
		for(int y = 0; y < cameraY; y++) {
			for(int x = 0; x < cameraX; x++) {
				try {
					p.print(x + 2, y + 2, "" + currMap[y + playerY - 5][x + playerX - 6]);
				} catch (ArrayIndexOutOfBoundsException ex) {
//				System.out.println("Camera out of bounds");	
				}
			}
		}
	}
	
	public void voidMap(Printer p) {
		if(currMap == mapOne) {
			for(int i = 0; i < 11; i++) {
				p.print(2, 2 + i, "###############");
			}
		}
		
	}
	
	int timer = 10;
	
	public void npcOneUpdate() {
		
		currMap[npcOneY][npcOneX] = npcOne;	
		npcOneDir = ran.nextInt(4);
		if(timer <= 0) {
			System.out.println(timer);
			if(!looking) {
				switch(npcOneDir) {
				case 0: 
					if(npcOneY >= 0 && currMap[npcOneY - 1][npcOneX] == blankSpace) {
						npcOneY--; 
						if(currMap[npcOneY + 1][npcOneX] == blankSpace || currMap[npcOneY + 1][npcOneX] == npcOne || currMap[npcOneY + 1][npcOneX] == player ) { 
							currMap[npcOneY + 1][npcOneX] = blankSpace;
						} 
						
					} break;
				case 1:
					if(npcOneY >= 0 && currMap[npcOneY + 1][npcOneX] == blankSpace) {
						npcOneY++; 
						if(currMap[npcOneY - 1][npcOneX] == blankSpace || currMap[npcOneY - 1][npcOneX] == npcOne || currMap[npcOneY - 1][npcOneX] == player ) { 
							currMap[npcOneY - 1][npcOneX] = blankSpace;
						} 
						
					} break;
				case 2:
					if(npcOneX >= 0 && currMap[npcOneY][npcOneX - 1] == blankSpace) {
						npcOneX--; 
						if(currMap[npcOneY][npcOneX + 1] == blankSpace || currMap[npcOneY][npcOneX + 1] == npcOne || currMap[npcOneY][npcOneX + 1] == player ) { 
							currMap[npcOneY][npcOneX + 1] = blankSpace;
						} 
						
					} break;
				case 3:
					if(npcOneX >= 0 && currMap[npcOneY][npcOneX + 1] == blankSpace) {
						npcOneX++; 
						if(currMap[npcOneY][npcOneX - 1] == blankSpace || currMap[npcOneY][npcOneX - 1] == npcOne || currMap[npcOneY][npcOneX - 1] == player ) { 
							currMap[npcOneY][npcOneX - 1] = blankSpace;
						} 
						
					} break;
				}
			}
			timer += 10;
		}
		timer--;
	}
	
	@Override
	public void update() {
		playerUpdate();
		doorCheck();
		if(currMap == houseOne) { 
			npcOneUpdate();
		}
	}

	@Override
	public void render(Printer p) {
		renderGuiBorder(p);
		renderGui(p);
		renderMapBorder(p);
		voidMap(p);
		renderMap(p);
		if(looking) {
			renderCursor();
			checkCursor(p);
		}
	}

	private void deloadCursor() {
		currMap[cursorY][cursorX - 1] = blankSpace;
		currMap[cursorY][cursorX] = blankSpace;
		if(currMap[cursorY][cursorX + 1] == look2) {
			currMap[cursorY][cursorX + 1] = blankSpace;
		}
	}

	private void renderCursor() {
		try {
			currMap[cursorY][cursorX - 1] = look1;	
			if(currMap[cursorY][cursorX - 2] == look1) {
				currMap[cursorY][cursorX - 2] = blankSpace;
			} else if(currMap[cursorY][cursorX + 1] == look2) {
				currMap[cursorY][cursorX + 1] = blankSpace;
			}
			currMap[cursorY][cursorX] = look2;	
		}
		catch(ArrayIndexOutOfBoundsException ex) { looking = false; deloadCursor(); }
	}
	
	private void checkCursor(Printer p) {
		if(currMap[cursorY][cursorX + 1] == 'T') {
			//Text area
			p.print(21, 11, "This is a Table.");
			p.print(21, 12, "It's made of maho");
			p.print(21, 13, "gany wood.");
		} else if(currMap[cursorY][cursorX + 1] == 'h') {
			//Text area
			p.print(21, 11, "This is a Chair.");
			p.print(21, 12, "It's made of maho");
			p.print(21, 13, "gany wood.");
		} else if(currMap[cursorY][cursorX + 1] == 'U') {
			//Text area
			p.print(21, 11, "This is a Person.");
			p.print(21, 12, "He is tall. He");
			p.print(21, 13, "also has a brown");
			p.print(21, 14, "beard.");
		}
	}

	@Override
	public void getInput(KeyManager key) {
		if(!looking) {
			try {
				if(key.up) {
					if(playerY >= 0 && currMap[playerY - 1][playerX] == blankSpace || currMap[playerY - 1][playerX] == 'D') {
						playerY--; 
						if(currMap[playerY + 1][playerX] == blankSpace || currMap[playerY + 1][playerX] == player) { 
							currMap[playerY + 1][playerX] = blankSpace;
						} 
						
					} 
				}
				else if(key.down) {
					if(playerY >= 0 && currMap[playerY + 1][playerX] == blankSpace || currMap[playerY + 1][playerX] == 'D') {
						playerY++; 
						if(currMap[playerY - 1][playerX] == blankSpace || currMap[playerY - 1][playerX] == player) {
							currMap[playerY - 1][playerX] = blankSpace; 
						} 
					} 
				}
				else if(key.left) {
					if(playerX >= 0 && currMap[playerY][playerX - 1] == blankSpace || currMap[playerY][playerX - 1] == 'D') {
						playerX--; 
						if(currMap[playerY][playerX + 1] == blankSpace || currMap[playerY][playerX + 1] == player) { 
							currMap[playerY][playerX + 1] = blankSpace; 
						} 
					} 
				}
				else if(key.right) {
					if(playerX >= 0 && currMap[playerY][playerX + 1] == blankSpace || currMap[playerY][playerX + 1] == 'D') {
						playerX++; 
						if(currMap[playerY][playerX - 1] == blankSpace || currMap[playerY][playerX - 1] == player) { 
							currMap[playerY][playerX - 1] = blankSpace; 
						} 
					} 
				}
				if(key.look) { looking = true; cursorX = (playerY - 1); cursorY = playerY; }
				textBox = "Nothing...";
			} catch(ArrayIndexOutOfBoundsException ex) {
				System.out.println("Cannot move here!");
			}
		}
		else {
			if(key.up) {
				if(cursorY >= 0 && currMap[cursorY - 1][cursorX] == blankSpace) {
					cursorY--; 
					if(currMap[cursorY + 1][cursorX] == blankSpace || currMap[cursorY + 1][cursorX] == look2 || currMap[cursorY + 1][cursorX - 1] == look1) { 
						currMap[cursorY + 1][cursorX] = blankSpace; currMap[cursorY + 1][cursorX - 1] = blankSpace; 
					} 
					
				} 
			}
			else if(key.down) {
				if(cursorY >= 0 && currMap[cursorY + 1][cursorX] == blankSpace) {
					cursorY++; 
					if(currMap[cursorY - 1][cursorX] == blankSpace || currMap[cursorY - 1][cursorX] == look2 || currMap[cursorY - 1][cursorX - 1] == look1) {
						currMap[cursorY - 1][cursorX] = blankSpace;  currMap[cursorY - 1][cursorX - 1] = blankSpace; 
					} 
				} 
			}
			else if(key.left) {
				if(cursorX >= 0 && currMap[cursorY][cursorX - 1] == look1) {
					cursorX--; 
					if(currMap[cursorY][cursorX + 1] == blankSpace || currMap[cursorY][cursorX + 1] == look1) { 
						currMap[cursorY][cursorX + 1] = blankSpace; 
					} 
				} 
			}
			else if(key.right) {
				if(cursorX >= 0 && currMap[cursorY][cursorX + 1] == blankSpace) {
					cursorX++; 
					if(currMap[cursorY][cursorX - 1] == blankSpace || currMap[cursorY][cursorX - 1] == look1) { 
						currMap[cursorY][cursorX - 1] = blankSpace; 
					} 
				} 
			}
			textBox = "Looking!";
			if(key.look) { looking = false; System.out.println("Hello World!"); deloadCursor(); cursorX = (playerY - 1); cursorY = playerY; }
		}
		
		if(key.enter) { System.exit(0); }
	}

}
